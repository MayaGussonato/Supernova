import api from "./Services";

const API_KEY = "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";

export const gerarResumo = async (titulo, descricao = "") => {
  try {
    const resposta = await api.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "user",
            content: `
              Faça um resumo simples do filme abaixo:

              Título: ${titulo}
            `,
          },
        ],
      },
      {
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
      },
    );

    return resposta.data.choices[0].message.content;
  } catch (erro) {
    console.error(erro);
    return "Erro ao gerar resumo.";
  }
};


//  Descrição:
// ${descricao}